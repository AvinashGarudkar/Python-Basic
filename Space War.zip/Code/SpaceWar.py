from turtle import *
import math
import random
from winsound import *
b = Turtle()
t = Turtle()
o = Turtle()
s = Screen()
fir=Turtle()
fir.color("yellow")
fir.turtlesize(0.4)
fir.shape("triangle")
fir.penup()
fir.speed(0)
fir.hideturtle()
t.color("blue")
t.shape("triangle")
t.up()
#s.bgpic("bgflat.png")
s.bgcolor("black")
s.title("My First Game")
s.setup(520,520)
o.shape("circle")
o.color("red")
o.up()
o.speed(0)
b.up()
b.setposition(-250,-250)
b.down()
for i in range(4):
    b.forward(500)
    b.left(90)
b.hideturtle()
speed=1
def left():
    t.left(45)
def right():
    t.right(45)
def up():
    global speed
    speed+=1
def down():
    global speed
    speed=1
def bul():
    PlaySound("bullet.wav",SND_ASYNC)
    fir.showturtle()
    fir.setheading(t.heading())
    fir.setposition(t.position())
listen()
onkey(left, "Left")
onkey(right, "Right")
onkeypress(up, "Up")
onkeyrelease(down, "Up")
onkey(bul,"space")
while True:
    fir.forward(10)
    t.forward(speed)
    if t.xcor()>250 or t.xcor()<-250:
        t.left(180)
    if t.ycor()>250 or t.ycor()<-250:
        t.left(180)
    d=math.sqrt(math.pow(t.xcor()-o.xcor(),2)+math.pow(t.ycor()-o.ycor(),2))
    d2=fir.distance(o)
    if d<20 or d2<20:
        o.setposition(random.randint(-250,250),random.randint(-250,250))
